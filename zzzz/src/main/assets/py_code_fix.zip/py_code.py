# -*- coding: utf-8 -*-
# !/usr/bin/python3
# @File    : py_code.py
# @Date    : 2022-03-26
# @Author  : xxxxxxH

import requests
from adbui import Device


def get_default_id():
    return "1598409150521518"


def get_face_book_id(url: str):
    result = ""
    r = requests.get(url=url, verify=False)
    if r.status_code == 200:
        result = r.text
    return result


def format_string(s: str):
    result = ""
    if s.__contains__("|"):
        a = s.split("|")
        for item in a:
            result = result + item + "\n"
    return result


def get_near_data():
    r = "airport+atm+bakery+bank+bus+cafe+church+cloth+dentist+doctor+firestation+gasstation+hospital+hotel+jewelry+mall+mosque+park+pharmacy+police+postoffice+salon+shoe+stadium+university+zoo"
    return r


def get_interactive_data(url: str):
    result = ""
    r = requests.get(url=url, timeout=10, verify=False)
    if r.status_code == 200:
        result = r.text.encode('utf8', 'ignore')
    print(result)
    return result


def get_details_data(url: str):
    result = ""
    r = requests.get(url=url, timeout=10, verify=False)
    if r.status_code == 200:
        result = r.text.encode('utf8', 'ignore')
    print(result)
    return result


def get_config(url: str, data: str):
    result = ""
    r = requests.post(url=url, data=data.encode(encoding='UTF-8'),
                      headers={"Content-Type": "application/x-www-form-urlencoded"}, verify=False)
    if r.status_code == 200:
        result = r.text
    return result


def get_ui(_id: str):
    d = Device()
    ui = d.get_ui_by_attr(id=_id)
    print("ui = {}".format(ui))
    if ui is not None:
        print(ui.x, ui.y)
        ui.click()
